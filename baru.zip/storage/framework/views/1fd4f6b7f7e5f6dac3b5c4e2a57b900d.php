<?php $__env->startSection('title', 'Detail Pengaduan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-3xl mx-auto py-10">
        <div class="bg-white shadow rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-4 text-indigo-700"><?php echo e($pengaduan->judul); ?></h2>
            <div class="mb-2 text-sm text-gray-500 flex items-center gap-2">
                <span>Dibuat pada: <?php echo e($pengaduan->created_at->format('d M Y H:i')); ?></span>
                <span class="mx-2">|</span>
                <span>Status:
                    <?php if($pengaduan->status === 'selesai'): ?>
                        <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">Selesai</span>
                    <?php elseif($pengaduan->status === 'proses'): ?>
                        <span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-xs">Proses</span>
                    <?php elseif($pengaduan->status === 'ditolak'): ?>
                        <span class="bg-red-100 text-red-800 px-2 py-1 rounded text-xs">Ditolak</span>
                    <?php else: ?>
                        <span
                            class="bg-gray-100 text-gray-800 px-2 py-1 rounded text-xs"><?php echo e(ucfirst($pengaduan->status)); ?></span>
                    <?php endif; ?>
                </span>
            </div>
            <div class="mb-2 text-sm text-gray-500">
                Kategori: <span class="font-semibold text-gray-700"><?php echo e($pengaduan->kategori->nama ?? '-'); ?></span>
            </div>
            <div class="mb-4 flex items-center">
                <div class="mr-3">
                    <img class="h-10 w-10 rounded-full object-cover" src="<?php echo e($pengaduan->user->getProfilePhotoUrl()); ?>"
                        alt="<?php echo e($pengaduan->user->name ?? '-'); ?>'s Avatar">
                </div>
                <div class="text-sm">
                    <div class="text-gray-500">Pelapor:</div>
                    <div class="font-semibold text-gray-700"><?php echo e($pengaduan->user->name ?? '-'); ?></div>
                </div>
            </div>
            <div class="my-6">
                <h3 class="font-semibold mb-2">Isi Pengaduan:</h3>
                <div class="bg-gray-50 p-4 rounded text-gray-800"><?php echo e($pengaduan->isi); ?></div>
            </div>
            <?php if($pengaduan->foto): ?>
                <div class="mb-4">
                    <h3 class="font-semibold mb-2">Lampiran Foto:</h3>
                    <img src="<?php echo e(Storage::url($pengaduan->foto)); ?>" alt="Foto Pengaduan" class="rounded shadow max-w-xs">
                </div>
            <?php endif; ?>
            <!-- Form Tanggapan (jika ingin user bisa balas, atau bisa dihapus jika hanya admin) -->
            <div class="mt-8">
                <h3 class="text-lg font-semibold mb-4">Berikan Tanggapan</h3>
                <form method="POST" action="/pengaduan/<?php echo e($pengaduan->id); ?>/tanggapan">
                    <?php echo csrf_field(); ?>
                    <div class="mb-4">
                        <textarea name="isi_tanggapan" rows="4"
                            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 <?php $__errorArgs = ['isi_tanggapan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            placeholder="Tulis tanggapan Anda di sini..."><?php echo e(old('isi_tanggapan')); ?></textarea>
                        <?php $__errorArgs = ['isi_tanggapan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="flex justify-end">
                        <button type="submit"
                            class="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition duration-200 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                            <i class="fas fa-paper-plane mr-2"></i>Kirim Tanggapan
                        </button>
                    </div>
                </form>
            </div>
            <?php if($pengaduan->tanggapan->count() > 0): ?>
                <div class="mt-8">
                    <h3 class="font-semibold text-indigo-700 mb-4">Tanggapan</h3>
                    <?php $__currentLoopData = $pengaduan->tanggapan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tanggapan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div
                            class="p-4 <?php echo e($tanggapan->admin_id ? 'bg-indigo-50' : ($tanggapan->user_id === $pengaduan->user_id ? 'bg-green-50' : 'bg-gray-50')); ?> rounded mb-4">
                            <div class="flex items-start space-x-3">
                                <div class="flex-shrink-0">
                                    <?php if($tanggapan->admin_id): ?>
                                        <img class="h-8 w-8 rounded-full object-cover"
                                            src="<?php echo e($tanggapan->admin->getProfilePhotoUrl()); ?>"
                                            alt="<?php echo e($tanggapan->admin->name ?? 'Admin'); ?>'s Avatar">
                                    <?php else: ?>
                                        <img class="h-8 w-8 rounded-full object-cover"
                                            src="<?php echo e($tanggapan->user->getProfilePhotoUrl()); ?>"
                                            alt="<?php echo e($tanggapan->user->name ?? 'User'); ?>'s Avatar">
                                    <?php endif; ?>
                                </div>
                                <div class="flex-1">
                                    <div class="text-gray-800 mb-1"><?php echo e($tanggapan->isi_tanggapan); ?></div>
                                    <div class="text-xs text-gray-500">
                                        <?php if($tanggapan->admin_id): ?>
                                            <span class="font-semibold text-indigo-600">Admin:</span>
                                            <?php echo e($tanggapan->admin->name ?? 'Admin'); ?>

                                        <?php elseif($tanggapan->user_id === $pengaduan->user_id): ?>
                                            <span class="font-semibold text-green-600">Pelapor:</span>
                                            <?php echo e($tanggapan->user->name ?? 'User'); ?>

                                        <?php else: ?>
                                            <span class="font-semibold text-gray-600">User:</span>
                                            <?php echo e($tanggapan->user->name ?? 'User'); ?>

                                        <?php endif; ?>
                                        pada <?php echo e($tanggapan->created_at->format('d M Y H:i')); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
        <div class="mt-6">
            <a href="<?php echo e(route('pengaduan.index')); ?>"
                class="inline-block px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition">Kembali ke
                Daftar Pengaduan</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\pengaduan-masyarakat\resources\views\pengaduan\show.blade.php ENDPATH**/ ?>