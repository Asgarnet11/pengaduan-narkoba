<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['isAdmin']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['isAdmin']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<nav x-data="{ open: false }"
    class="sticky top-0 z-50 bg-white shadow-md backdrop-blur supports-backdrop-blur:bg-white/95">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
            <!-- Logo and Primary Nav -->
            <div class="flex items-center">
                <div class="shrink-0 flex items-center">
                    <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center space-x-3 group">
                        <i
                            class="fas fa-building text-2xl text-indigo-600 group-hover:scale-110 transition-transform duration-300"></i>
                        <span class="text-xl font-bold text-gradient">Pengaduan</span>
                    </a>
                </div>

                <!-- Primary Navigation -->
                <?php if(auth()->guard()->check()): ?>
                    <div class="hidden space-x-8 sm:-my-px sm:ml-10 sm:flex">
                        <a href="<?php echo e(url('/')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'inline-flex items-center px-1 pt-1 text-sm font-medium transition-all duration-300',
                            'text-gray-900 border-b-2 border-indigo-500' => request()->is('/'),
                            'text-gray-500 hover:text-gray-700 hover:border-b-2 hover:border-gray-300' => !request()->is(
                                '/'),
                        ]); ?>">
                            <i class="fas fa-home mr-2"></i>
                            Home
                        </a>

                        <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'inline-flex items-center px-1 pt-1 text-sm font-medium transition-all duration-300',
                            'text-gray-900 border-b-2 border-indigo-500' => request()->routeIs(
                                'dashboard'),
                            'text-gray-500 hover:text-gray-700 hover:border-b-2 hover:border-gray-300' => !request()->routeIs(
                                'dashboard'),
                        ]); ?>">
                            <i class="fas fa-table-columns mr-2"></i>
                            Dashboard
                        </a>

                        <a href="<?php echo e(route('pengaduan.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'inline-flex items-center px-1 pt-1 text-sm font-medium transition-all duration-300',
                            'text-gray-900 border-b-2 border-indigo-500' => request()->routeIs(
                                'pengaduan.*'),
                            'text-gray-500 hover:text-gray-700 hover:border-b-2 hover:border-gray-300' => !request()->routeIs(
                                'pengaduan.*'),
                        ]); ?>">
                            <i class="fas fa-file-alt mr-2"></i>
                            Pengaduan
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Search and User Menu -->
            <div class="hidden sm:flex sm:items-center sm:ml-6 space-x-4">
                <?php if(auth()->guard()->check()): ?>
                    <!-- Search Bar -->
                    <div class="relative" x-data="{ isOpen: false, query: '' }" @click.away="isOpen = false">
                        <div class="relative">
                            <input type="text" x-model="query" @focus="isOpen = true"
                                @input.debounce.300ms="if(query.length >= 3) $dispatch('search-query', { query: query })"
                                placeholder="Cari pengaduan..."
                                class="w-64 pl-10 pr-4 py-2 text-sm text-gray-700 bg-gray-50 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all duration-300">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-search text-gray-400"></i>
                            </div>
                        </div>

                        <!-- Search Results -->
                        <div x-show="isOpen && query.length >= 3" x-cloak
                            class="absolute mt-2 w-96 bg-white rounded-lg shadow-lg py-2 z-50 max-h-96 overflow-y-auto"
                            x-transition:enter="transition ease-out duration-200"
                            x-transition:enter-start="opacity-0 transform scale-95"
                            x-transition:enter-end="opacity-100 transform scale-100"
                            x-transition:leave="transition ease-in duration-100"
                            x-transition:leave-start="opacity-100 transform scale-100"
                            x-transition:leave-end="opacity-0 transform scale-95">
                            <div class="px-4 py-2 border-b border-gray-100">
                                <p class="text-sm text-gray-500">Hasil Pencarian</p>
                            </div>
                            <div id="searchResults" class="max-h-[400px] overflow-y-auto">
                                <!-- Search results will be injected here -->
                            </div>
                        </div>
                    </div>

                    <!-- User Menu -->
                    <div class="ml-3 relative" x-data="{ open: false }">
                        <div>
                            <button @click="open = !open"
                                class="flex items-center space-x-3 text-sm focus:outline-none transition duration-300 ease-in-out hover:opacity-80">
                                <img class="h-8 w-8 rounded-full object-cover border-2 border-indigo-500"
                                    src="<?php echo e(auth()->user()->getProfilePhotoUrl()); ?>"
                                    alt="<?php echo e(auth()->user()->name); ?>'s Avatar">
                                <div class="hidden md:block text-left">
                                    <span class="block text-gray-900"><?php echo e(auth()->user()->name); ?></span>
                                    <span class="block text-xs text-gray-500"><?php echo e(auth()->user()->email); ?></span>
                                </div>
                                <i class="fas fa-chevron-down text-gray-400"></i>
                            </button>
                        </div>

                        <!-- User Dropdown -->
                        <div x-show="open" x-cloak @click.away="open = false"
                            class="origin-top-right absolute right-0 mt-2 w-48 rounded-lg shadow-lg bg-white ring-1 ring-black ring-opacity-5"
                            x-transition:enter="transition ease-out duration-200"
                            x-transition:enter-start="opacity-0 transform scale-95"
                            x-transition:enter-end="opacity-100 transform scale-100"
                            x-transition:leave="transition ease-in duration-75"
                            x-transition:leave-start="opacity-100 transform scale-100"
                            x-transition:leave-end="opacity-0 transform scale-95">
                            <div class="py-1">
                                <a href="<?php echo e(route('profile.edit')); ?>"
                                    class="group flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-indigo-50 transition-all duration-300">
                                    <i class="fas fa-user mr-3 text-gray-400 group-hover:text-indigo-500"></i>
                                    Profile
                                </a>
                                <form method="POST" action="<?php echo e(route('logout')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"
                                        class="w-full group flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-indigo-50 transition-all duration-300">
                                        <i class="fas fa-sign-out-alt mr-3 text-gray-400 group-hover:text-indigo-500"></i>
                                        Keluar
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="flex space-x-4">
                        <a href="<?php echo e(route('login')); ?>"
                            class="inline-flex items-center px-4 py-2 text-sm font-medium text-black bg-blue-100 border border-indigo-600 rounded-lg hover:bg-indigo-50 transition-all duration-300">
                            <i class="fas fa-sign-in-alt mr-2"></i>
                            Login
                        </a>
                        <a href="<?php echo e(route('register')); ?>"
                            class="inline-flex items-center px-4 py-2 text-sm font-medium text-black bg-blue-100 border border-transparent rounded-lg hover:bg-indigo-700 transition-all duration-300">
                            <i class="fas fa-user-plus mr-2"></i>
                            Register
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Mobile menu button -->
            <div class="-mr-2 flex items-center sm:hidden">
                <button @click="open = !open"
                    class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:bg-gray-100 focus:text-gray-500 transition duration-150 ease-in-out">
                    <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                        <path :class="{ 'hidden': open, 'inline-flex': !open }" class="inline-flex"
                            stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4 6h16M4 12h16M4 18h16" />
                        <path :class="{ 'hidden': !open, 'inline-flex': open }" class="hidden" stroke-linecap="round"
                            stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
        </div>
    </div>

    <!-- Mobile menu -->
    <div :class="{ 'block': open, 'hidden': !open }" class="sm:hidden">
        <?php if(auth()->guard()->check()): ?>
            <div class="pt-2 pb-3 space-y-1">
                <?php if (isset($component)) { $__componentOriginald69b52d99510f1e7cd3d80070b28ca18 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.responsive-nav-link','data' => ['href' => route('dashboard'),'active' => request()->routeIs('dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('dashboard')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('dashboard'))]); ?>
                    <i class="fas fa-home mr-2"></i>
                    Dashboard
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $attributes = $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $component = $__componentOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginald69b52d99510f1e7cd3d80070b28ca18 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.responsive-nav-link','data' => ['href' => route('pengaduan.index'),'active' => request()->routeIs('pengaduan.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('pengaduan.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('pengaduan.*'))]); ?>
                    <i class="fas fa-file-alt mr-2"></i>
                    Pengaduan
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $attributes = $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $component = $__componentOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>

                <?php if($isAdmin): ?>
                    <?php if (isset($component)) { $__componentOriginald69b52d99510f1e7cd3d80070b28ca18 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.responsive-nav-link','data' => ['href' => route('admin.dashboard'),'active' => request()->routeIs('admin.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.dashboard')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.*'))]); ?>
                        <i class="fas fa-shield-alt mr-2"></i>
                        Admin Panel
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $attributes = $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $component = $__componentOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
                <?php endif; ?>
            </div>

            <!-- Mobile user menu -->
            <div class="pt-4 pb-1 border-t border-gray-200">
                <div class="flex items-center px-4">
                    <div class="shrink-0">
                        <img class="h-10 w-10 rounded-full object-cover" src="<?php echo e(auth()->user()->getProfilePhotoUrl()); ?>"
                            alt="<?php echo e(auth()->user()->name); ?>'s Avatar">
                    </div>
                    <div class="ml-3">
                        <div class="font-medium text-base text-gray-800"><?php echo e(auth()->user()->name); ?></div>
                        <div class="font-medium text-sm text-gray-500"><?php echo e(auth()->user()->email); ?></div>
                    </div>
                </div>

                <div class="mt-3 space-y-1">
                    <?php if (isset($component)) { $__componentOriginald69b52d99510f1e7cd3d80070b28ca18 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.responsive-nav-link','data' => ['href' => route('profile.edit')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('profile.edit'))]); ?>
                        <i class="fas fa-user mr-2"></i>
                        Profile
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $attributes = $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $component = $__componentOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>

                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php if (isset($component)) { $__componentOriginald69b52d99510f1e7cd3d80070b28ca18 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.responsive-nav-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault(); this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault(); this.closest(\'form\').submit();']); ?>
                            <i class="fas fa-sign-out-alt mr-2"></i>
                            Keluar
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $attributes = $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $component = $__componentOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
                    </form>
                </div>
            </div>
        <?php else: ?>
            <div class="pt-2 pb-3 space-y-1 text-gray-900 border-blue-400 bg-blue-900 hover:bg-blue-400">
                <?php if (isset($component)) { $__componentOriginald69b52d99510f1e7cd3d80070b28ca18 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.responsive-nav-link','data' => ['href' => route('login')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('login'))]); ?>
                    <i class="fas fa-sign-in-alt mr-2"></i>
                    Login
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $attributes = $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $component = $__componentOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginald69b52d99510f1e7cd3d80070b28ca18 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.responsive-nav-link','data' => ['href' => route('register')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('register'))]); ?>
                    <i class="fas fa-user-plus mr-2"></i>
                    Register
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $attributes = $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $component = $__componentOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</nav>

<?php $__env->startPush('scripts'); ?>
    <script>
        // Search functionality
        window.addEventListener('search-query', event => {
            const query = event.detail.query;
            fetch(`/search?q=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(results => {
                    const searchResults = document.getElementById('searchResults');
                    if (results.length === 0) {
                        searchResults.innerHTML = `
                    <div class="flex flex-col items-center justify-center py-8">
                        <img src="https://illustrations.popsy.co/gray/falling-box.svg" alt="No Results" class="w-24 h-24 mb-4">
                        <p class="text-sm text-gray-500">Tidak ada hasil yang ditemukan</p>
                    </div>
                `;
                        return;
                    }

                    searchResults.innerHTML = results.map(result => `
                <a href="${result.url}" class="block px-4 py-3 hover:bg-gray-50 transition duration-200">
                    <div class="flex items-start space-x-3">
                        <img class="h-8 w-8 rounded-full object-cover flex-shrink-0" src="${result.photo_url}" alt="${result.pelapor}'s Avatar">
                        <div class="flex-1 min-w-0">
                            <div class="flex justify-between items-start">
                                <div class="truncate">
                                    <p class="text-sm font-medium text-gray-900">${result.judul}</p>
                                    <p class="text-xs text-gray-600 truncate">${result.isi}</p>
                                </div>
                                <span class="ml-2 px-2 py-1 text-xs rounded-full whitespace-nowrap ${getStatusClass(result.status)}">
                                    ${ucfirst(result.status)}
                                </span>
                            </div>
                            <div class="mt-1 flex items-center text-xs text-gray-500">
                                <span class="flex items-center">
                                    <i class="far fa-user mr-1"></i>
                                    ${result.pelapor}
                                    ${result.is_own ? '<span class="ml-1 px-1.5 py-0.5 text-xs bg-indigo-100 text-indigo-800 rounded-full">Anda</span>' : ''}
                                </span>
                                <span class="mx-2">•</span>
                                <span class="flex items-center">
                                    <i class="far fa-folder mr-1"></i>
                                    ${result.kategori}
                                </span>
                                <span class="mx-2">•</span>
                                <span>${result.created_at}</span>
                            </div>
                        </div>
                    </div>
                </a>
            `).join('<div class="border-t border-gray-100"></div>');
                });
        });

        function ucfirst(string) {
            return string.charAt(0).toUpperCase() + string.slice(1);
        }

        function getStatusClass(status) {
            switch (status) {
                case 'selesai':
                    return 'bg-green-100 text-green-800';
                case 'diproses':
                    return 'bg-yellow-100 text-yellow-800';
                case 'ditolak':
                    return 'bg-red-100 text-red-800';
                default:
                    return 'bg-gray-100 text-gray-800';
            }
        }
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\laragon\www\pengaduan-masyarakat\resources\views/components/navigation.blade.php ENDPATH**/ ?>